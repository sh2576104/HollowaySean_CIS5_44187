/* 
  File:   main.cpp
  Author: Sean Holloway
  Created on February 28, 2017, 4:34 PM
  Purpose:  Sum of Two Numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input values
   int number;
    number = 50 + 100;
    cout << "50" << endl;
    cout << "100" <<endl;
    cout << "Total = " << number << endl;
    //Process by mapping inputs to outputs
    
    //Output values
    
    //Exit stage right!
    return 0;
}