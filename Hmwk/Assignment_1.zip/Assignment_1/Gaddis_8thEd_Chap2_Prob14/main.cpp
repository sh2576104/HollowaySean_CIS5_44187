/* 
  File:   main.cpp
  Author: Sean Holloway
  Created on February 28, 2017, 9:00 PM
  Purpose:  Personal Information
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input values
    
    //Process by mapping inputs to outputs
    
    //Output values
    cout<<"Name"<<endl;
    cout<<"Address,with city,state, and ZIP code"<<endl;
    cout<<"Phone Number"<<endl;
    cout<<"Major"<<endl;

    //Exit stage right!
    return 0;
}